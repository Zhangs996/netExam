function submit(){
	document.getElementById("submit_jump").submit();
}